<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\CodeIgniter;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

class Main extends BaseController
{


    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
    }
        
    
    public function index() {
        return view('index');
    }
    
    public function page2(){

        echo view('index2');
    }
    public function page3(){

        echo view('index3');
    }
    public function page4(){

        echo view('index4');
    }
}
