<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'index');
$routes->get('page2', 'index2');
$routes->get('page3', 'index3');
$routes->get('page4', 'index4');
