<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="<?= base_url('node_modules/bootstrap/dist/css/bootstrap.min.js'); ?>"></script>
    <link rel="stylesheet" href="<?= base_url('node_modules/bootstrap/dist/css/bootstrap.min.css'); ?>">
</head>
<body>


<h2>Basic HTML code for Navbar</h2>
<div class="container">
    <ul>
        <li><a href="#home">Home</a></li>
        <li><a href="#news">News</a></li>
         <li><a href="#contact">Contact</a></li>
         <li><a href="#about">About</a></li>
    </ul>

    <p>Note: We use href="#" for links. In a real website this would be URLs.</p>   
    	<h3>jak se máme</h3>
</div>
</body>
</html>




    <h2>Hlavní strana</h2>
    

<?= anchor('main_page', 'První stránka');?>
<?php 
$imageProperties = array('src' => 'app/config/images/image.jpg',
                            'class' => 'img-fluid'                            
);
$imageProperties = [];
echo img($imageProperties);
 img('app/config/images/image.jpg') ?>
 <?= $this ->endSection();?>
</body>
</html>