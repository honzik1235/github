<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <script src="<?= base_url('node_modules/bootstrap/dist/css/bootstrap.min.js'); ?>"></script>
    <link rel="stylesheet" href="node_modules/bootstrap/dist/js/bootstrap.min.js">
    <style>
        body {
          background-image: url('more.jpg');
          background-size: 1920px 1080px;
        }
        </style>
</head>


<body>
    
   
    <nav style="
  height: 50px;
  background: linear-gradient( #009246 33.33%, #ffffff 33.33%, #ffffff 66.66%, #ce2b37 66.66%);
  display: flex;
  justify-content: center;
        ">          
            <ul class="nav">
            <li class="nav-item"><a href="index.php" class="item">Úvod</a></li>
                <li class="nav-item"><a href="index2.php" class="item">Hory</a></li>
                <li class="nav-item"><a href="index3.php" class="item">Moře</a></li>
                <li class="nav-item"><a href="index4.php" class="item">Jídlo</a></li>
                <div class="flag-icon">
                    <span class="fi fi-it"></span>
                  </div>
            </ul>
        </nav>
        
    <h1 style="padding-top: 70px;">Od studených hor k teplým mořím...</h1>
   
    <p style="font-size: large;">Itálie je zemí kontrastů, kde se na relativně malém území střetávají drsné vrcholky hor a teplé, slunečné pobřeží. Na severu se tyčí majestátní Alpy a Dolomity, kde vládne chladné horské klima a zimní sporty mají své nezaměnitelné kouzlo. Zasněžené vrcholky, ledovce a horské průsmyky lákají turisty i milovníky adrenalinu. O pár stovek kilometrů dál na jih pak najdeme italská moře – Tyrhénské, Jaderské či Středozemní – kde se počasí mění na příjemně teplé, s palmami a zlatými plážemi.</p>
        
    <h1>Oblíbené destinace</h1>
    <div class="container mt-3">

      <div class="row">

          <div class="col-md-4">
              <div class="card">
                <div class="flag-icon">
                  </div>
                  <img class="card-img-top" src="rim.jpg" alt="Card image" style="width:100%">
                  <div class="card-body">
                      <h4 class="card-title">Řím</h4>
                      <p style="font-size: large; color: black;"class="card-text">Řím, hlavní město Itálie, je považováno za jedno z nejvýznamnějších historických a kulturních center světa. Město je známé svými antickými památkami, jako je Koloseum, Forum Romanum a Pantheon. Řím je také sídlem Vatikánu, duchovního centra katolické církve. Kromě historických míst nabízí Řím i vynikající italskou kuchyni, kavárny a živou atmosféru.</p>
                      <a href="index5.html" class="btn btn-primary">Zjistit více</a>
                  </div>
              </div>
          </div>
 <div class="col-md-4">
              <div class="card">
                  <img class="card-img-top" src="milano.jpg" alt="Card image" style="width:100%">
                  <div class="card-body">
                      <h4 class="card-title">Milano</h4>
                      <p style="font-size: large; color: black;"class="card-text">Milán je jedním z nejdůležitějších měst Itálie, známý jako světová metropole módy a designu. Město je domovem některých z nejznámějších módních značek a butiků. Kromě toho je Milán proslulý svou gotickou katedrálou, Duomo di Milano, a mistrovským dílem Leonarda da Vinciho – Poslední večeří. Milán také nabízí vynikající gastronomii, umělecké galerie a moderní architekturu.</p>
                      <a href="index5.html" class="btn btn-primary">Zjistit více</a>
                  </div>
              </div>
          </div>
  
          <div class="col-md-4">
              <div class="card">
                <span class="fi fi-it"></span>
                  <img class="card-img-top" src="perugia.jpg" alt="Card image" style="width:100%">
                  <div class="card-body">
                      <h4 class="card-title">Perugia</h4>
                      <p style="font-size: large; color: black;"class="card-text">Perugia je malebné město ve střední Itálii, známé svou bohatou historií, renesančními paláci a úzkými křivolakými uličkami. Je také známá svou čokoládou, konkrétně značkou Perugina, která vyrábí slavné bonbóny Baci. Perugia je ideálním místem pro milovníky historie a umění.</p>
                      <a href="index5.html" class="btn btn-primary">Zjistit více</a>
                  </div>
              </div>
          </div>
      </div> 
  </div> 

    </div>
  </div>
  

  <script>
        
    document.addEventListener("mousemove", function(e) {
        
        const x = e.clientX / window.innerWidth * 50; 
        const y = e.clientY / window.innerHeight * 50; 
        document.body.style.backgroundPosition = `${x}% ${y}%`;
    });
</script>
<footer style="margin: 0; font-family: Arial, sans-serif; background-color: #333; color: white; text-align: center; padding: 15px 0;">
    CHcete vědět více o našich zájezdech? <a href="kontakt.html">Kontaktujte nás!</a>
  </footer>
</body>
</html>