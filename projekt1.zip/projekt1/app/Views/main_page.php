<?= $this->extend('layout/template'); ?>
<?= $this->section('content');?>
    <h1>Nadpiss</h1>
    <?= anchor('page2', 'Druhá stránka');?>
    <?= img('images/image.jpg') ?>
    <?= $this->endSection(); ?>