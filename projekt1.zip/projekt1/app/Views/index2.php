<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <script src="<?= base_url('node_modules/bootstrap/dist/css/bootstrap.min.js'); ?>"></script>
    <link rel="stylesheet" href="node_modules/bootstrap/dist/js/bootstrap.min.js">
    <style>
        body {
          background-image: url('alpy.jpg');
        }
        </style>
</head>
<body>
    <!DOCTYPE html>
    <html lang="en">
    
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link type="text/css" rel="stylesheet" href="style.css" class="ul.nav2">
        
    </head>
    
    <body>
        
    <?php include 'navbar.php'; ?>
        <h1 style="font-size: 50px; padding-top: 50px;">Italské hory</h1>
       
        
            <div class="header">
                <h1 style="font-size: 50px; padding-top: 50px;">Nejvyšší Italské hory:</h1>
            </div>
        
            <div class="table-container">
                <table>
                    <thead>
                      <tr>
                        <th>Jméno</th>
                        <th>Výška m.n.m.</th>
                        <th>Pohoří</th>
                        <th>Složení</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Monte Bianco</td>
                        <td>4810</td>
                        <td>Alpy</td>
                        <td>Žula, vápenec</td>
                      </tr>
                      <tr>
                        <td>Marmolada</td>
                        <td>3343</td>
                        <td>Dolomity</td>
                        <td>Dolomit</td>
                      </tr>
                      <tr>
                        <td>Gran Paradiso</td>
                        <td>4061</td>
                        <td>Alpy</td>
                        <td>Žula</td>
                      </tr>
                    </tbody>
                  </table>
                  
            </div>
            <p style="font-size: large; padding-left: 150px; padding-right: 150px;">Italské hory patří k nejkrásnějším a nejrozmanitějším horským oblastem v Evropě. Od majestátních Dolomit na severovýchodě až po zasněžené vrcholky Alp a malebné kopce Toskánska – Itálie nabízí ideální podmínky pro milovníky přírody, turistiky i zimních sportů. Hory v Itálii nejsou jen o nádherných výhledech a čerstvém vzduchu, ale také o bohaté kultuře horských vesnic, tradičních specialit a pohostinnosti místních obyvatel. Ať už hledáte dobrodružství na sjezdovkách, nebo klidné túry po zelených úbočích, italské hory vám přinesou nezapomenutelné zážitky.</p>
            
    <script>
        
      document.addEventListener("mousemove", function(e) {
          
          const x = e.clientX / window.innerWidth * 50; 
          const y = e.clientY / window.innerHeight * 50; 
          document.body.style.backgroundPosition = `${x}% ${y}%`;
      });
  </script>
  
    </body>
    
    
</html>