<!DOCTYPE html>
<html lang="cs">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="style.css">
        <script src="<?= base_url('node_modules/bootstrap/dist/css/bootstrap.min.js'); ?>"></script>
        <link rel="stylesheet" href="node_modules/bootstrap/dist/js/bootstrap.min.js">
<style>
        body {
            margin: 0;
            height: 100vh;
            background-image: url('italie.jpg');
            background-size: 120% 120%;
            background-attachment: fixed;
            transition: background-position 0.1s ease-out;
            color: white;
        }

    

</style>        
<body>

    <nav style="
    height: 50px;
    background: linear-gradient( #009246 33.33%, #ffffff 33.33%, #ffffff 66.66%, #ce2b37 66.66%);
    display: flex;
    justify-content: center;
          ">          
              <ul class="nav">
              <li class="nav-item"><a href="index.php" class="item">Úvod</a></li>
                <li class="nav-item"><a href="index2.php" class="item">Hory</a></li>
                <li class="nav-item"><a href="index3.php" class="item">Moře</a></li>
                <li class="nav-item"><a href="index4.php" class="item">Jídlo</a></li>
              </ul>
          </nav>
          <h1 style="font-size: 50px; padding-top: 50px;">Úvod</h1>
         
          
              <div class="header">
                  <h1 style="font-size: 50px; padding-top: 50px; padding-bottom: 150px;">Co vše určitě zažít v Itálii</h1>
              </div>


<div class="container news-container mt-5">
  <div class="row gx-4 gy-4">
    <div class="col-lg-6">
      <div class="card h-100">
        <img src="milano.jpg" class="card-img-top" alt="Benátky">
        <div class="card-body">
          <h5 class="card-title">Pozor! Na plážích v okolí Benátek je přeplněno!</h5>
          <p class="card-text" style="font-size: large;">Benátky lákají davy turistů, ale jejich okolní pláže v letní sezóně trpí nadměrnou návštěvností. Vyplatí se plánovat výlety mimo špičku.</p>
          <a href="#" class="btn btn-primary">Číst více</a>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="row gy-4">
        <div class="col-md-6">
          <div class="card h-100">
            <img src="more.jpg" class="card-img-top" alt="Toskánsko">
            <div class="card-body">
              <h6 class="card-title">Toskánsko – kraj vinic a klidu</h6>
              <a href="#" class="btn btn-sm btn-outline-primary">Číst</a>
            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="card h-100">
            <img src="rim.jpg" class="card-img-top" alt="Řím">
            <div class="card-body">
              <h6 class="card-title">Řím – věčné město plné historie</h6>
              <a href="#" class="btn btn-sm btn-outline-primary">Číst</a>
            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="card h-100">
            <img src="italy.jpg" class="card-img-top" alt="Amalfi">
            <div class="card-body">
              <h6 class="card-title">Amalfinské pobřeží jako z pohádky</h6>
              <a href="#" class="btn btn-sm btn-outline-primary">Číst</a>
            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="card h-100">
            <img src="jidlo.jpeg" class="card-img-top" alt="Italská kuchyně">
            <div class="card-body">
              <h6 class="card-title">Italská kuchyně: Co musíte ochutnat</h6>
              <a href="#" class="btn btn-sm btn-outline-primary">Číst</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<footer style=" padding-top : 50px; font-family: Arial, sans-serif; background-color: #333; color: white; text-align: center; padding: 15px 0;">
    CHcete vědět více o našich zájezdech? <a href="kontakt.html">Kontaktujte nás!</a>
  </footer>
<script>
    document.addEventListener("mousemove", function(e) {
        const x = e.clientX / window.innerWidth * 50;
        const y = e.clientY / window.innerHeight * 50;
        document.body.style.backgroundPosition = `${x}% ${y}%`;
    });
</script>
</body>
</html>
