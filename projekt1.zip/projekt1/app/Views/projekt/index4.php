<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Jídlo - Carousel</title>
    <link rel="stylesheet" href="style.css">
    <script src="<?= base_url('node_modules/bootstrap/dist/css/bootstrap.min.js'); ?>"></script>
    <link rel="stylesheet" href="<?= base_url('node_modules/bootstrap/dist/css/bootstrap.min.css'); ?>">
    <style>
        body {
            background-image: url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1920&q=80');
            background-size: cover;
            background-attachment: fixed;
            color: black;
            padding: 20px;
        }
        
    </style>
</head>
<body>

  <nav style="
  height: 50px;
  background: linear-gradient( #009246 33.33%, #ffffff 33.33%, #ffffff 66.66%, #ce2b37 66.66%);
  display: flex;
  justify-content: center;
        ">          
            <ul class="nav">
                <li class="nav-item"><a href="index.php" class="item">Úvod</a></li>
                <li class="nav-item"><a href="index2.php" class="item">Hory</a></li>
                <li class="nav-item"><a href="index3.php" class="item">Moře</a></li>
                <li class="nav-item"><a href="index4.php" class="item">Jídlo</a></li>
            </ul>
        </nav>

<h1 style="font-size: 50px; padding-top: 50px;">Jídlo</h1>

<p class="intro fs-6 fs-md-5 fs-lg-4" style="font-size: large;">
    Italská kuchyně je považována za jednu z nejlepších na světě. Touto kuchyní se inspirovalo mnoho a mnoho dalších. Těšit se v ní můžeme na různé druhy masa a ryb, zeleninu (uvařenou na mnoho způsobů), těstoviny (Itálie se může pyšnit více než 400 druhy), nádivky, zmrzliny (italské zmrzliny jsou považovány také za jedny z nejlepších), dezerty. Podle množství zemědělských plodin se dělí na tři skupiny: severní, střední a jižní.
</p>

<div class=" container-fluid px-5">

  <div id="myCarousel" class="carousel slide mt-5 " data-bs-ride="carousel">
    <div class="carousel-inner">

      <div class="carousel-item active">
        <div class="row g-0">
          <div class="col-md-6">
            <img src="jidlo1.jpg" class="img-fluid w-100 h-100 object-fit-cover" alt="Obrázek 1">
          </div>
          <div class="col-md-6 d-flex align-items-center justify-content-center bg-light">
            <div class="p-4 w-100 text-center ">
              <h3 style="color: #333;">Tradiční Lasagne</h3>
              <p style="color: #333;">Lasagne jsou jedním z nejznámějších pokrmů italské kuchyně.Skládají se z vrstev těstovin, bohaté masové omáčky ragù,jemného bešamelu a sýra, obvykle parmezánu.Pečou se dozlatova a podávají se jako sytý hlavní chod,který potěší každého milovníka italských chutí. </p>
              
            </div>
          </div>
        </div>
      </div>

      <div class="carousel-item">
        <div class="row g-0">
          <div class="col-md-6">
            <img src="jidlo2.jpg" class="img-fluid w-100 h-100 object-fit-cover" alt="Obrázek 2">
          </div>
          <div class="col-md-6 d-flex align-items-center justify-content-center bg-light">
            <div class="p-4 w-100 text-center">
              <h3>Čerstvá Pizza Margherita</h3>
              <p>Pizza Margherita je jednoduchá, ale ikonická –</p>
              <p>rajčatový základ, čerstvá mozzarella, bazalka a olivový olej.</p>
              <p>Legenda praví, že vznikla na počest italské královny Margherity.</p>
              <p>Barvy ingrediencí symbolizují italskou vlajku:</p>
              <p>zelená, bílá a červená – čistá chuť Itálie na jednom talíři.</p>
            </div>
          </div>
        </div>
      </div>

      <div class="carousel-item">
        <div class="row g-0">
          <div class="col-md-6">
            <img src="jidlo3.jpg" class="img-fluid w-100 h-100 object-fit-cover" alt="Obrázek 2">
          </div>
          <div class="col-md-6 d-flex align-items-center justify-content-center bg-light">
            <div class="p-4 w-100 text-center">
              <h3>Sladké Tiramisu</h3>
              <p>Tiramisu je nejslavnější italský dezert –</p>
              <p>vrstvy piškotů namočených v kávě, mascarpone krému</p>
              <p>a posypané kakaem tvoří dokonalou harmonii chutí.</p>
              <p>Pochází z oblasti Benátska a jeho název znamená „Zvedni mě“ –</p>
              <p>přesně to, co udělá každému, kdo ho ochutná.</p>
            </div>
          </div>
        </div>
      </div>

    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon bg-dark"></span>
      <span class="visually-hidden">Předchozí</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon bg-dark"></span>
      <span class="visually-hidden">Další</span>
    </button>
  </div>
</div>
<footer style="margin: 0; font-family: Arial, sans-serif; background-color: #333; color: white; text-align: center; padding: 15px 0;">
  CHcete vědět více o našich zájezdech? <a href="kontakt.html">Kontaktujte nás!</a>
</footer>

</body>
</html>

