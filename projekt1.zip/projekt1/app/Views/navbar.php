<!DOCTYPE html>
<html>
<body>

<nav style="
    height: 50px;
    background: linear-gradient( #009246 33.33%, #ffffff 33.33%, #ffffff 66.66%, #ce2b37 66.66%);
    display: flex;
    justify-content: center;
          ">          
              <ul class="nav">
              <li class="nav-item"><a href="index.php" class="item">Úvod</a></li>
                <li class="nav-item"><a href="index2.php" class="item">Hory</a></li>
                <li class="nav-item"><a href="index3.php" class="item">Moře</a></li>
                <li class="nav-item"><a href="index4.php" class="item">Jídlo</a></li>
              </ul>
          </nav>
</div>
</body>
</html>


