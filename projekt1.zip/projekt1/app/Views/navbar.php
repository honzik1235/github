<!DOCTYPE html>
<html>
<body>

<h2>Basic HTML code for Navbar</h2>
<div class="container">
    <ul>
        <li><a href="#home">Home</a></li>
        <li><a href="#news">News</a></li>
         <li><a href="#contact">Contact</a></li>
         <li><a href="#about">About</a></li>
    </ul>

    <p>Note: We use href="#" for links. In a real website this would be URLs.</p>   
    	<h3>jak se máme</h3>
</div>
</body>
</html>


